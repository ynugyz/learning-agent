---
name: learning-knowledge-growth-workbuddy
display_name: Learning Knowledge Growth
display_name_en: Learning Knowledge Growth
description: Compile transcripts, slides, PDFs, documents, images, and project files into linked Human and AI knowledge notes and editable Excalidraw diagrams in WorkBuddy.
description_zh: 在 WorkBuddy 中将转写、课件、PDF、图片和项目资料整理为可连接、可持续生长的人类笔记与 AI 知识层。
description_en: Compile transcripts, slides, PDFs, images, and project files into linked, incrementally growing Human and AI knowledge notes in WorkBuddy.
version: 0.4.1
author: Learning Agent
user-invocable: true
---

# WorkBuddy 使用约定

这是 WorkBuddy 适配版。执行前读取与当前资料类型相关的参考：

- @references/input-modes.md：PDF、PPT、图片、项目等非纯文本资料。
- @references/note-writing.md：简明提要、重点解释与详细整理。
- @references/ai-index-protocol.md：AI 层检索、来源、哈希与增量更新。
- @references/workbuddy-harness.md：WorkBuddy 权限、Skill 绑定、模型和测试方式。

WorkBuddy 的模型由当前 Expert、工作模式或 Buddy App 配置决定，Skill 不硬编码模型名称或平台凭证。使用用户在 WorkBuddy 中选定的模型；模型可以是 DeepSeek 或平台提供的其它模型。Skill 只规定资料处理和输出行为。
这是 WorkBuddy 本地资料版 Skill。它只处理当前对话附件和用户明确授权的目录；模型、账号和其它服务由 WorkBuddy 自己管理，Skill 不主动连接外部服务。
为降低首次使用门槛：如果用户只提供一个已授权工作区并明确同意，可以在其中使用 inbox、human-notes、ai-knowledge 三个子目录；如果用户已经给出两个输出目录，优先使用用户给出的目录，不要自行改写。

SKILL.md 下方的学习编译规则来自 Learning Agent 的规范版本。保留两个独立输出根目录，并在 WorkBuddy 已授权可访问的文件夹内运行。
# Learning Knowledge Growth

Use this skill when the user supplies learning materials and wants them compiled into an existing or new knowledge system.

## Required first-use setup

Before the first run, require two explicit output directories from the user:

- Human output root: Markdown notes for reading, review, and Obsidian linking.
- AI output root: machine artifacts and durable semantic state for later runs.

If the user already provided both paths in the current conversation, use them. Otherwise ask for exactly those two paths and stop before processing input. Save the resolved paths in a small configuration file named knowledge-growth.config.json in the selected AI output root or a separate workspace directory. Never put this configuration or intermediate artifacts in the production Vault by default.

On later runs, reuse the saved paths unless the user explicitly changes them. Treat the two roots as independent; do not place machine JSON beside the human Markdown unless the user deliberately chose the same directory.

## Intake questions

At the beginning of a new course or a new kind of material, ask the user for two small preferences before deep processing, unless the user has already answered them in the current conversation:

1. **Material type** — choose one or more: `课堂转写`, `课件/PPT`, `PDF/教材/文档`, `图片/扫描资料`, `项目/代码/ZIP`, or `混合资料`.
2. **Explanation depth / 笔记展开程度** — offer `简明提要` (core concepts explained briefly with their key reasoning; everything else as short cues), `重点解释（推荐）` (core concepts explained with mechanism, conditions and a representative example; secondary items brief or folded), or `详细整理` (retain source-supported detail, including requested examples and derivations). All three use the same core/secondary/name-only tiers. Explain the difference by how much is developed, not by promising that the longest option is best.

Course option `reviewChecklist` (`待复习清单`): `按课次考点` (default, no need to ask) keeps the per-lesson must-master checklist in the course MOC; `关闭` turns it off. Save a changed value with the other course preferences. If several files have different types, record a type for each file and use `混合资料` for the batch. Reuse a clear preference, or ask once and save the answer in the existing course metadata or setup configuration; no per-run manifest or new configuration schema is required. “简洁 / 知道是什么即可 / 不懂我自己查” selects `简明提要` directly. When the user delegates the choice (`AI 自行取舍`), treat core concepts as `重点解释` and secondary items as `简明提要`. Recognize saved legacy values: `完整保留` means `详细整理`, `平衡整理` means `重点解释`, and `AI 自行取舍` means this tiered adaptive behavior. The user's current request overrides a saved preference; do not silently override an explicit request for full detail. Depth governs newly written explanations, not permission to discard valid existing content. Read [references/note-writing.md](references/note-writing.md) before drafting Human Notes.

## Inputs and routing

Accept files attached to the conversation or paths supplied by the user. Classify every input before compiling:

- .txt, .md, audio transcript, or pasted text: evidence source; use the existing SourceMap -> LessonModel -> Alignment -> ChangePlan pipeline.
- .pptx, .ppt, .pdf, images, or documents: inspect visible text, headings, formulas, tables, and diagrams with the appropriate document, presentation, or PDF tools. Preserve the original file as evidence and create a bounded normalized source for the pipeline. Mark information that cannot be read or verified as deferred.
- A project folder, .zip, or source tree: inspect its manifest and the smallest relevant set of files; treat code, README, diagrams, and examples as learning evidence. Do not recursively ingest unrelated build output or dependencies.
- Existing Markdown notes: seed Knowledge State, not new source material. Preserve useful definitions, formulas, examples, comparisons, methods, boundaries, study guidance, and links.

Infer the course or subject from an explicit user label, selected folder, existing profile, or the material itself. If two subjects are plausible, ask before writing. For a new subject, use a bounded snapshot of the selected course folder and create a new profile candidate rather than scanning the Vault.

Use the input type to choose the reading tool before compiling. Read [references/input-modes.md](references/input-modes.md) when the batch contains anything beyond plain text. The tool is for extraction and evidence navigation; it must not turn the source into an unsupported textbook summary:

- `课堂转写` / `.txt` / pasted text: read the source directly and preserve source spans, repetitions that carry teaching value, examples, formulas, and uncertainty.
- `课件/PPT` / `.pptx` / `.ppt`: use the presentation-reading capability to inspect slide text, speaker notes, tables, formulas, diagrams, and slide order; keep slide numbers as provenance.
- `PDF/教材/文档`: use the PDF or document-reading capability appropriate to the file. Render pages when layout, formulas, tables, or diagrams affect meaning; keep page numbers and extraction limits.
- `图片/扫描资料`: use image understanding or image viewing to read visible text, handwriting, formulas, and diagrams; mark unreadable regions as deferred instead of guessing.
- `项目/代码/ZIP`: inspect the manifest and the smallest relevant set of README, source, examples, and diagrams; do not ingest dependencies or build output.
- `混合资料`: route each file with its own tool, then reconcile them as one bounded lesson only when their topic and scope match.

Preserve the original files as evidence. If a tool can extract only part of a file, record what was read and what was unavailable; do not silently treat a partial extraction as complete.

## Compilation behavior

Use the model configured by the WorkBuddy harness for reasoning and generation. Do not launch DSH, Jev, or a second model provider from a script; DeepSeek may be the model selected in WorkBuddy. Do not require the user to understand or operate the internal stages.

Use the bundled companion repository (or its configured local checkout) for versioned prompts, schemas, course profiles, and conventions. The skill may use one WorkBuddy turn or several bounded internal passes. It may create temporary evidence maps, knowledge objects, alignment drafts, and change drafts as working memory, but these are implementation details rather than user-facing requirements.

For text inputs, read the selected profile or bounded course folder, the original source, and a small set of existing seed notes. Keep the original input immutable. Reuse the repository's SourceMap, LessonModel, Alignment, and ChangePlan semantics internally when useful, but one WorkBuddy orchestration may perform the whole compilation.

Use single-topic compilation by default. When several source files are attached,
group them by clearly distinct topic and produce a focused note at the selected depth;
do not rebuild an entire course unless the user explicitly requests a course
rebuild. A broad course folder is context for routing, not a reason to pass every
page into every note generation call.

For non-text inputs, first extract or transcribe only the bounded relevant content into the run workspace, record the original file and extraction method in provenance, then run the same compilation stages. Do not silently invent missing formulas or diagram content.

When a source PDF or slide contains a useful diagram, chart, spatial layout or visual derivation, consider embedding a selected original screenshot beside the relevant explanation. Follow the selection, attachment and cleanup rules in [references/input-modes.md](references/input-modes.md). Images supplement readable knowledge; do not turn a deck into a screenshot dump or replace searchable formulas with pictures.

Before finalizing any note, run the **Visual channel** checklist below; it is part of compilation, not an optional extra.

Before accepting any machine intermediate, run a deterministic contract pass. For SourceMap, `sources[].quality` must be exactly an object with `rating` (`clean`, `noisy`, `partial`, `unreadable`, or `unknown`) and optional schema-approved `issues`/`note`; if the configured model returns a useful description without `rating`, derive the least-committal rating and retain the description in the bounded `note`, then remove protocol-unknown keys. Keep raw responses only in the temporary workspace while repairing or diagnosing a failure; never promote them to durable knowledge output. A single mechanical shape mismatch must not trigger full-pipeline regeneration.

Before an expensive Alignment or ChangePlan judgment, run a deterministic unchanged prefilter. Compare the stable knowledge identity, relevant source hashes and locators, current Human Note hash, relevant AI-card hash, requested explanation depth, task scope, and dependent relation/source hashes with the last known state. Only an exact match with all required values present may be marked `reuse_unchanged` and skip the semantic decision. A keyword match, embedding score, similar summary, or missing hash is never enough. If any value is unknown, stale, newly scoped, or associated with an uncertain/conflicted source, route the object through the normal Alignment and ChangePlan path. The prefilter is a cost gate, not a truth check and not a new relation value; it must never hide a required update. In a batch, count prefiltered objects and evaluated objects separately so the saving can be compared with update recall.

The Human Note should cover every distinct subject concept actually mentioned within the user's selected source scope, including secondary concepts, concepts appearing only in examples, and name-only mentions. Coverage is not uniform weight: tier each concept from source signals (teaching time, repetition, explicit emphasis or exam hints, prerequisite role, mechanism/formula centrality, taught confusions) as core, secondary, or name-only. Core concepts are explained with their mechanism, reasoning chain, conditions, formulas and distinctions in the main text; secondary concepts get a sentence or two beside the core concept they serve or in a folded callout; name-only and uncertain items go to a page-end question callout; non-representative examples are omitted. Follow [references/note-writing.md](references/note-writing.md) for the tiers, the fixed callout vocabulary, lesson-page shape, and a deduplicated concept-to-output check kept in internal or temporary working memory, not a new permanent table or schema. The user's explicit scope and requests for examples, methods or fuller explanation take precedence.

Preserve valid existing content during authorized updates; add or revise only genuinely new meaning, not another paraphrase of the same idea. Every new knowledge claim must be supported by supplied material or valid existing notes. Do not invent definitions, examples, causes, mistakes or missing formulas from model memory. The one bounded exception is an external supplement: when the teacher spends substantial time on a real-world case, data or social phenomenon whose figures or facts were not supplied, the host offers search or page-reading tools, and the user has authorized web lookup for this course or run, retrieve traceable public sources (official statistics first), redraw charts from public data rather than copying images, and place the result only in an `> [!abstract] 外部补充` callout with source and access date. External findings never rewrite the teacher's statements; a contradiction becomes a CONFLICT or review item. Follow section 5 of [references/note-writing.md](references/note-writing.md). Mark actual evidence gaps briefly; choosing not to elaborate a supported point is not a gap. Deliver formal knowledge notes without `candidate`, `draft`, `preview`, run IDs or pipeline status in their names or learning prose.

Change planning is non-destructive by default. A proposed update may add supported meaning, narrow a claim to its evidenced scope, add a relation, or correct the specific claim that reliable evidence overturns. It must preserve compatible old wording, source references and unrelated sections. Never silently discard a page, card, section, example, relation or prior formulation merely because the newest source omits it; deletion or archival requires an explicit user instruction. If the proposed operation would remove information, retain the old state and mark the difference for review instead.

Use numbered second-level headings in every delivered Human Note: `## 1. ...`, `## 2. ...`, and so on, consecutively in document order. Keep them as headings, not numbered list items, and normalize existing heading numbers instead of adding duplicate prefixes. Number third-level headings when they express ordered steps, a progression, or a parallel set that benefits from numbered reference, using the parent number (`### 2.1 ...`, `### 2.2 ...`). Otherwise use descriptive unnumbered third-level headings; keep the choice consistent within a sibling group. This does not require numbering the page title or turning all body bullets into ordered lists. Use prose, lists, tables and headings according to the knowledge relationship, avoiding a page made entirely of nested bullets. Before delivery, check the real heading structure outside code fences and quoted source examples, including consecutive H2 numbers and consistent H3 parent numbers. When renaming a heading in an authorized update, synchronize affected section links and AI section references without changing stable knowledge IDs; do not scan or rewrite unrelated notes to enforce this style.

Make importance visible through layout: numbered H2 sections carry the main line and open with the point they settle; core content stays unfolded in prose, tables and display formulas; secondary terms and representative examples use folded `note`/`example` callouts; genuine confusions use a `warning` callout; sources and open items go to folded callouts at the page end, with line numbers and hashes kept in the AI layer. Do not write generic disclaimers ("不能把……当作……") that name no concrete misunderstanding; put conditions directly beside the definition or formula. Compress repetition, setup, transitions and paraphrase, not the reasoning: keep the classroom's causal chain, intuition and contrasts for core concepts. `例：一年期存款` can still replace a long setup. Write Obsidian Properties only for useful `aliases` unless the user has another convention, and never rewrite an old note's existing frontmatter. Link display text is plain text: never put `$...$`, quotes or other Markdown inside a wikilink alias, give links to headings that contain math a plain alias, and do not wrap links or formulas in quotation marks. Keep each H2 readable on its own so a reader or Copilot-style tool can select it and ask follow-up questions.

Render mathematics as Obsidian Markdown/LaTeX, never as unmarked plain text. Use single dollar delimiters for inline expressions (`$...$`) and double dollar delimiters on separate lines for display expressions (`$$...$$`). Keep the opening and closing delimiters paired, keep display delimiters on their own lines, and do not mix Markdown code fences with formula delimiters. Preserve an explicitly missing or uncertain formula as a clearly marked missing item instead of inventing it. Before delivery, scan the final Markdown for unpaired dollar delimiters and repair only unambiguous cases.

Build the surrounding knowledge network while writing the note. Each knowledge object has one home page (its card's `humanNoteRef`) where it is fully developed; other pages give a one-sentence summary plus a link, or embed `![[home#section]]` when the whole block is needed, instead of restating it. Dated lesson pages are thin indexes of what the class covered, teacher emphasis, the user's own handwritten notes, and gaps, linking to home sections. Unless the course preference `reviewChecklist` is `关闭`, the course MOC keeps a `待复习` checklist grouped by lesson in teaching order: for every processed transcript append one `### MM-DD topic · [[lesson page]]` group listing only the must-master points of that lesson (teacher emphasis, exam hints, prerequisites for later lessons, taught confusions), each written as a short self-test question without answer links (the MOC's review maps carry navigation). Never reword, untick or move items the user has ticked; follow the MOC rules in [references/note-writing.md](references/note-writing.md). Place links inside the sentence where the relation is stated and name the relation, linking to a specific heading when possible; avoid section-opening "延伸：" lines and repeating one link in every section. Reuse resolvable wikilinks to existing course notes and bounded reference notes when the relationship is supported by the input; add links for prerequisites, examples, contrasts, applications, and closely related concepts. Apply a dedicated page-level link pass before delivery: whenever a course scope, module list, outline, table of contents, relation list, or knowledge-map sentence names an existing loaded note or a loaded note's exact alias, write that item as an Obsidian wikilink at its first meaningful mention (for example, `[[货币与信用]]`), even when the item is also a broad category. If the visible wording is more descriptive than the target filename, use `[[Target|visible wording]]`. A category label is not a reason to leave an otherwise resolvable knowledge page unlinked. Do not create decorative links or link to files that were not loaded. Keep provenance and stable machine identity in the AI layer; do not add a separate provenance or manifest file merely to hold metadata.

Treat retrieval relevance as a routing signal, not as proof. A BM25/vector match can select candidate notes or source units, but it cannot authorize a merge, correction or factual claim. For each written claim, keep a source locator or a valid existing-note reference. Re-open the original span for formulas and their conditions, numerical or historical claims, teacher examples generalized into rules, corrections/conflicts, and any claim whose source is uncertain. If the source does not support the wording, shorten it to the supported observation, mark it as uncertain/deferred, or omit it; do not repair the gap from model memory. Use this targeted support check instead of an expensive fact-checking call for every ordinary claim.

Use an evidence packet only as temporary context selection, never as a durable third layer. For each object, select the smallest set of source excerpts that covers the definition, conditions, variables/formula, distinguishing example, boundary, method choice, or disagreement needed by the proposed claim. Attach the original source ID and locator to every excerpt, add adjacent context when a qualification depends on it, deduplicate identical spans, and widen the packet when coverage or support is incomplete. Apply any token budget after coverage is satisfied. Selecting or ranking this packet is deterministic context work; do not spend a generative model call to summarize evidence before the note-writing call.

The AI layer must be a retrieval layer, not a second copy of Human Markdown. Maintain two progressively loaded levels:

- **Course index (L0)**: one small `index.json` per course. It maps sources to note records, stable `knowledgeId`s, aliases, note paths, maintenance state, open items, hashes and page-level relations. It answers “which pages and objects are relevant?” without opening full notes.
- **Knowledge object cards (L1)**: compact records under `cards/` for concepts, mechanisms, formulas, methods, examples, boundaries and unresolved objects. Each card has a stable identity, canonical term, aliases, role, bounded semantic core, only the key claims needed for retrieval, section anchors, human-note reference, source references, relations and update state. Card size and claim count follow object complexity; do not force unrelated evidence gaps into a fixed template or one catch-all card. It answers “which object and section should change?”

Use L0/L1 routing before opening historical Human Note sections (L2) and evidence (L3). This limits repeated historical retrieval, not the initial understanding of the current authorized material: establish its coverage before choosing smaller context for each later decision. Never recreate L1 by copying a whole Human Note. Human Markdown must not be polluted with machine IDs or JSON metadata. Before marking a run successful, resolve affected card relation targets, note paths, section anchors and image references; record the scope of the final integrity status rather than implying a full-Vault check. Read [references/ai-index-protocol.md](references/ai-index-protocol.md) when creating or updating the AI layer.

## Visual channel (mandatory checklist)

Run this checklist for every note before delivery. Each step is an execution requirement, not a suggestion; skipping a step is a failed run, not a lighter one. A user or project instruction to keep work lightweight limits extra pages, schemas and pipelines; it does not waive this checklist.

1. **Read the visual rules first.** Before drawing anything, read [references/visuals-and-excalidraw.md](references/visuals-and-excalidraw.md) in full. It holds the form choice, figure quality rules, interactive HTML rules and review-map rules. [references/obsidian-excalidraw-cli.md](references/obsidian-excalidraw-cli.md) only covers editing scenes through Obsidian and is not a substitute.
2. **Decide per learning question.** Look for a process, structure, comparison, timeline, variable relationship, mathematical construction, coordinate relation, function shape, geometric figure, vector, probability tree or matrix layout, and for any concrete question that positions, paths, shapes or changes would answer more clearly. Choose by what the question depends on: Excalidraw for shapes, positions, curve shifts, coordinates, geometry, data trends and side-by-side panels; an Obsidian Mermaid block only for flows, causal chains and hierarchies with no spatial meaning; a Markdown table for attribute comparisons. Describing a shape or curve shift in words, a table or a box-and-arrow diagram does not satisfy the decision. When the teacher draws or points at a figure that was not supplied, reconstruct it as a labelled schematic, plotting only stated values. When this applies, set `visualNeed=editable-diagram`.
3. **Draw from computed values.** Build coordinate planes, computed curves, curve shifts, number lines and multi-panel figures by computing every curve point from the source formula, so curves come from the source formula rather than hand-placed pixels. Use the Obsidian CLI or an available Excalidraw MCP/App only for small labelled schematics or for editing an existing scene. Never invent nodes, arrows, coordinates, curves, geometry, labels or equations.
4. **Look at the figure and lint it.** Render every new or changed scene with the host image preview and look at it; check binding consistency. Deliver only when the preview shows no text under about 12 px at the display width, no text crossed by a line, no captions or source notes inside the figure, no boxes stuffed with paragraphs, no hand-drawn style.
5. **Interactive mechanism model.** For every core mechanism driven by a source formula or variable relationship (for example a curve that shifts when one variable changes, a result that depends on two or three parameters, a step-by-step state change), build a self-contained interactive mechanism model as one self-contained HTML file, with sliders and presets matching the lesson's cases, embedded through the user's HTML-embed plugin (for example Embed HTML's `![[file.html|-]]`) beside a static figure. Data trends may get an interactive HTML chart the same way. Label any assumption added only to make it move, on the page and in the card's `uncertainty`, and check one preset by hand. In the run summary, list each core mechanism with either the model file or the reason none was built.
6. **Chapter review map.** Each chapter with about six or more related knowledge objects keeps one Excalidraw review map (`复习地图-<章节名>.excalidraw.md`) generated from existing card `relations`: one linked box per growing or stable object pointing to its home section, page regions, bound arrows labelled with the relation type, zero box crossings and zero label overlaps. Update the same map when the chapter's objects, relations or headings change, keeping the user's moved nodes and own annotations. The map is a view of the AI layer, never a new source of knowledge.
7. **Embed correctly.** Every embed stands on its own line with blank lines around it, follows the text that explains it, names an explicit display width, and has its caption as Markdown text below it. The durable file is modern `.excalidraw.md` embedded by file name; a PNG/SVG is only an optional preview kept out of the Vault unless asked.

Do not silently downgrade an eligible diagram to text-only output, and never make Excalidraw a required call for ordinary text with no source-supported visual relation.

## Output placement

Use a disposable run workspace outside both final roots (for example, a configured workspace `runs/<run-id>`). It may contain extracted source, provenance, temporary knowledge objects, alignment decisions and repair material while the run is executing. These files are working memory, not a third knowledge layer.

After validation, the durable result is deliberately small:

- formal Human Notes (or additive updates) under the Human output root, plus only the selected source images they use in `_assets/learning/`; these attachments belong to the Human layer;
- one AI knowledge layer under the AI output root: `index.json` and the affected `cards/<knowledgeId>.json` files;
- the one-time `knowledge-growth.config.json` setup file, kept outside the Human Note tree;
- optionally, one overwritten `last-run.md` containing at most a few lines for the user's orientation. It is not required for retrieval or self-growth and must never become a timestamped history.

Do not create a per-run manifest, a full change log, a duplicate provenance file, or a permanent audit directory by default. Source references, note hashes, maintenance state, unresolved items and relations belong in the AI index/cards; the conversation report can state what changed. If the user explicitly asks for a review bundle, export it separately and discard it after review.

Once the Human Note, its attachments and AI index/cards pass their integrity checks, discard the entire temporary run workspace, including raw model responses and unselected page/slide renders. First verify that final image links resolve outside that workspace; retain the referenced Human attachments. Do not discard the original source files or existing shared attachments. If a run fails, write one compact `run-error.md` (or report the error in the conversation) and discard the temporary workspace unless the user explicitly asks to retain diagnostics. Never present a partial artifact as a finished note.

The normal successful result is the formal Human Note and its corresponding AI knowledge state, written to the configured separate roots. Do not label successful outputs as candidates. When a target already exists, preserve useful content and integrate supported changes without appending duplicate explanations. A concise preference is not permission to batch-shorten old notes; apply it to new text unless the user authorizes a specific rewrite scope. A short change summary may be shown in the conversation, but is not a required file and should not accumulate on disk. Do not discard existing knowledge automatically.

A malformed model response may receive bounded mechanical repair, but do not regenerate the entire pipeline unnecessarily.

## Self-growth and later runs

On every later run, load the previous course index first, then retrieve only the matching knowledge cards and Human Note sections. Match new lesson objects against canonical terms, aliases, claims, section anchors and relations before considering a new page. Use stable note identity and source provenance to decide NEW, EXPAND, REFINE, RELATION, CORRECT, CONFLICT, or NO_CHANGE. When an object already has a home page and the new source adds no new meaning, the change is a source annotation or a link from the current page, never a second write-up on another page. Evidence uncertainty belongs in Alignment; ChangePlan decides proposed mutations. A deferred item remains reactivatable when new evidence arrives. Update the index and affected cards atomically with the Human Note change. Keep the new note hash, source references, maintenance state and open items in the AI layer; do not create a manifest solely to record old/new hashes.

For update decisions, keep three meanings separate: maintain an already supported state; profile/hold a plausible but insufficiently supported difference; correct only when reliable evidence overturns the existing claim. Use the existing `NO_CHANGE`/`resolutionState`, `maintenanceState: deferred`, and `CORRECT` semantics rather than inventing a new relation enum. A held item must stay discoverable and reactivatable; it must not overwrite the Human Note or be presented as settled knowledge. If a change is skipped by the unchanged check, report it as a deterministic reuse in the conversation rather than silently treating it as a fresh semantic decision.

Every successful run must report in the conversation input files and their types, selected course, Human output path, AI output path, validation status, deferred items, missing evidence, links added or updated, and whether any production Vault write occurred. A run ID may be mentioned for troubleshooting, but does not need to survive as a permanent file.

## Scope and safety

Never search the entire Vault. Use explicit course profiles, selected folders, or bounded existing-note references. Never modify or discard existing notes without an explicit write request. Keep credentials in environment configuration; do not copy them into notes, manifests, or skill files.
